package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.layer2.Customer;
import com.example.demo.layer2.Property;
import com.example.demo.layer3.CustomerReposioryImpl;
import com.example.demo.layer3.PropertyRepositoryImpl;

@SpringBootTest
public class OneToOneTests {
	@Autowired
	PropertyRepositoryImpl proRepo;
	
	@Autowired
	CustomerReposioryImpl cusRepo;
	
	@Test
	void OneToOneTest()
	{
		Customer customer=cusRepo.selectCustomer(1);
		Property property=proRepo.selectProperty(6);
		
		customer.setProperty(property);
		property.setCustomer(customer);
		
		cusRepo.merge(property);
		proRepo.merge(customer);
		
		
	}
}
