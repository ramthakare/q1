package com.example.demo;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.layer2.Customer;

import com.example.demo.layer2.Property;
import com.example.demo.layer3.CustomerReposioryImpl;

@SpringBootTest
class HomeLoanApplicationTests {
	@Autowired
	CustomerReposioryImpl cusRepo;
	@Test
	void insertCusTest()
	{
		Customer Cus=new  Customer();
		
		Cus.setFirstName("Krushna");
		Cus.setMiddleName("Gajanan");
		Cus.setLastName("Thakare");
		Cus.setEmail("krushnathakare4797@gmail.com");
		Cus.setPassword("ram@1234");
		Cus.setPhoneNo(89990706);
		Cus.setDob(LocalDate.of(2021, 11, 25));
		Cus.setNationality("Indian");
		Cus.setAdhaarNo(1234542232);
		Cus.setPanCard("Ramkr223t8");
		cusRepo.insertCustomer(Cus);
		
}

	@Test
	void selectCusTest()
	{
		Customer cus;
		cus=cusRepo.selectCustomer(3);
		System.out.println("repo : cus "+cus);
		System.out.println("cus"+cus.getCust_Id());
		System.out.println("cus "+cus.getFirstName());
		System.out.println("cus "+cus.getMiddleName());
		System.out.println("cus "+cus.getLastName());
		System.out.println("cus "+cus.getAdhaarNo());
		System.out.println("cus "+cus.getEmail());
		System.out.println("cus "+cus.getNationality());
		System.out.println("cus "+cus.getPanCard());
	
		
		
}
	
	@Test
	void selectAllCustTest()
	{
		List<Customer> custList;
		custList=cusRepo.selectCustomers();
		for(Customer cus :custList)
		{
			System.out.println("cus"+cus.getCust_Id());
			System.out.println("cus "+cus.getFirstName());
			System.out.println("cus "+cus.getMiddleName());
			System.out.println("cus "+cus.getLastName());
			System.out.println("cus "+cus.getAdhaarNo());
			System.out.println("cus "+cus.getEmail());
			System.out.println("cus "+cus.getNationality());
			System.out.println("cus "+cus.getPanCard());
		
			
		}
		
		
		

		
	}
	@Test
	void updateCustTest()
	{
		//LocalDate ID=LocalDate.of(1999, 12, 30);
		Customer Cus=new Customer();
		
		
		Cus.setFirstName("Satish");
		Cus.setMiddleName("Ashok");
		Cus.setLastName("Thakare");
		Cus.setEmail("Satish4797@gmail.com");
		Cus.setPassword("ram@827761");
		Cus.setPhoneNo(96573768);
		Cus.setDob(LocalDate.of(2022, 11, 25));
		Cus.setNationality("Indian");
		Cus.setAdhaarNo(123454232);
		Cus.setPanCard("Ramkr223t8");
		
		
		cusRepo.updateCustomer(Cus);
	}
	@Test
	void deleteDeptTest()
	{
		Customer Cus=new Customer();
		Cus.getCust_Id();
		cusRepo.selectCustomer(2);
	}

}
