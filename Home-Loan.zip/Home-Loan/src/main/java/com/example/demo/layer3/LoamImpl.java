package com.example.demo.layer3;

public class LoamImpl implements LoanRepo{

}
